<?php 
class Api extends CI_Controller
{   
    function __construct()
    {
        parent::__construct();
        header('Access-Control-Allow-Origin: *');
        header("Content-Type:application/json");
        header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method , Authentication");
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
        $method = $_SERVER['REQUEST_METHOD'];
        if($method == "OPTIONS") {
        die();
        if ($this->input->server('REQUEST_METHOD') == 'GET')
            $postdata = json_encode($_GET);
        else if ($this->input->server('REQUEST_METHOD') == 'POST')
            $postdata = file_get_contents("php://input");
        
        $auth = '';

            if(isset(apache_request_headers()['Auth'])) {
                $auth = apache_request_headers()['Auth'];
            }
        
        }
    }
    
    public function index()
    {
        die('Working');
    }

    public function getvideoInfo()
    {
        header('Content-type: application/json');
        $postdata = file_get_contents("php://input");
        $request = json_decode($postdata,true);
        $url = $request['link']; 
        $respon = $this->getMaindata($url);
        print_r($respon);die;
        $count = explode("\"contentUrl\":\"", $respon);
        $videoinfo = explode("\"", $count[1])[0];
        $videoWithoutWaterMark = $this->getWithoutWatermark($videoinfo);
        $thumburl = explode("\"", explode("\"thumbnailUrl\":[\"", $respon)[1])[0];
        $userdetail = explode("/", explode("@", explode("\"", explode("\"url\":\"", $respon)[1])[0])[1])[0];
        
            if (count($count) > 1) {
                $response = array(
                    'mainvideo'=>$videoinfo,
                    'videowithoutWaterMark'=>$videoWithoutWaterMark,
                    'userdetail'=>$userdetail,
                    'thumbnail'=>$thumburl
                );
                $main = array('status' =>'success','message' =>"Video with Watermark",'responsecode'=>'200','data'=>$response);

            }
            else
            {
                $response = array(
                    'mainvideo'=>"",
                    'videowithoutWaterMark'=>"",
                    'userdetail'=>"",
                    'thumbnail'=>""
                );

                $main = array('status' =>'error' ,'message' =>"Please provide correct video url",'responsecode'=>'500','data'=>"");
            }
        
        echo  json_encode($main);
    }


    public function getWithoutWatermark($url)
    {
        $response = $this->curlUrlfunction($url);
        $extactdata = explode("vid:",$response);
        $vedioid = explode("%",$extactdata[1]);
        $vediostring = str_replace(' ', '-', $vedioid[0]); 

        $finalVid =  preg_replace('/[^A-Za-z0-9\-]/', '', $vediostring); 
        $returnUrl = "https://api2.musical.ly/aweme/v1/playwm/?video_id=".$finalVid;
        return $returnUrl;
    }

    public function curlUrlfunction($url)
    {
        $agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36';
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_USERAGENT, $agent);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        $result = curl_exec($ch);
        curl_close($ch);

        return $result;

    }

    public function getMaindata($url)
    {
        $ch = curl_init();
        $options = array(
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36',
            CURLOPT_ENCODING       => "utf-8",
            CURLOPT_AUTOREFERER    => true,
            CURLOPT_CONNECTTIMEOUT => 30,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_MAXREDIRS      => 10,
        );
        curl_setopt_array( $ch, $options );
        if (defined('CURLOPT_IPRESOLVE') && defined('CURL_IPRESOLVE_V4')) {
            curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        }
        $result = curl_exec($ch);
        curl_close($ch);
        return strval($result);
    }
    
    public function getContent()
	{
        header('Content-type: application/json');
        $postdata = file_get_contents("php://input");
        $request = json_decode($postdata,true);
        $url = $request['link'];				
			$web_page = $this->url_get_contents($url);
    		preg_match_all('/<script id="__NEXT_DATA__" type="application\/json" crossorigin="anonymous">(.*?)<\/script>/', $web_page, $match);
	        if (isset($match[1][0]) != "") 
	        {
	            $data = json_decode($match[1][0], true);
	            $video["userdetail"] = $data["props"]["pageProps"]["shareMeta"]["title"];
	            $video["thumbnail"] = $data['props']['pageProps']['shareMeta']['image']['url'];
	            $video_url = $data["props"]["pageProps"]["videoData"]["itemInfos"]["video"]["urls"][0];
	            $video_data = $this->url_get_contents($video_url);
	            $matches = array();
	            $pattern = '/vid:([a-zA-Z0-9]+)/';
	            preg_match($pattern, $video_data, $matches);
	            if (count($matches) > 1) {
	                $video["videowithoutWaterMark"] = "http://api2.musical.ly/aweme/v1/play/?video_id=" . $matches[1];
	                
	            } 
	            else 
	            {
	                $video["videowithoutWaterMark"] = $video_url;
	            }
	            $mainvideo = $video_url;
	            $response = array(
                    'mainvideo'=>$mainvideo,
                    'videowithoutWaterMark'=>  $video["videowithoutWaterMark"],
                    'userdetail'=>$video["userdetail"],
                    'thumbnail'=>$video["thumbnail"]
                );
                $main = array('status' =>'success','message' =>"Video without Watermark",'responsecode'=>'200','data'=>$response);
                echo  json_encode($main);
	        } 
	}
	
	function url_get_contents($url)
	{
	    $ch = curl_init();
	    curl_setopt($ch, CURLOPT_HEADER, 0);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	    curl_setopt($ch, CURLOPT_URL, $url);
	    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36');
	    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);	    
	    $chunkSize = 1000000;
	    curl_setopt($ch, CURLOPT_TIMEOUT, (int)ceil(3 * (round($chunkSize / 1048576, 2) / (1 / 8))));	   
	    curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
	    $data = curl_exec($ch);
	    curl_close($ch);
	    return $data;
	}
    
}